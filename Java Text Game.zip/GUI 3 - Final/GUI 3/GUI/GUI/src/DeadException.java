package game;

public class DeadException extends Exception
{
    public DeadException(String string)
    {
        super(string);
    }
}
