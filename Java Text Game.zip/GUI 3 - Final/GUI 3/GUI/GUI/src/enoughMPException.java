package game;

class enoughMpException extends Exception
{
    public enoughMpException(String string)
    {
        super(string);
    }
}
